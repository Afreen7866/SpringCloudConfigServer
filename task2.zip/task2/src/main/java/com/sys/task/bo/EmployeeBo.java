package com.sys.task.bo;

import com.sys.task.entity.EmployeeVo;

public interface EmployeeBo {

	public EmployeeVo[] getAllEmployeeVo();
	public EmployeeVo[] getEmployeebyRT();

}
